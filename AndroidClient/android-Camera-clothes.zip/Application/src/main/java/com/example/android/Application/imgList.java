package com.example.android.Application;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;


public class imgList implements Serializable
{
	private static final long serialVersionUID = 1L;
	ArrayList<byte[]> imageList;
	ArrayList<String> textList;
	Context context;
	Intent intent;

	Bitmap Bimg[];
	File file;
	FileWriter fileWrite;
	public imgList(ArrayList<byte[]> i, ArrayList<String> t)
	{
		imageList = i;
		textList = t;
	}
	void setContext(Context c)
	{
		context = c;
		intent = new Intent(context,showListActivity.class);
	}
	void showimg()
	{
		Log.i("sock : ","showimg started");
//		for(int i = 0; i<imageList.size(); i++)
//		{
//			Bimg[i] = BitmapFactory.decodeStream(new ByteArrayInputStream(imageList.get(i)));
//			System.out.print("Bitmap"+i+" "+BitmapFactory.decodeStream(new ByteArrayInputStream(imageList.get(i))));
//			Log.i("sock : ","bitmap "+i);
//			ImageIO.write(img,"jpg",new File("C:\\RImage\\img"+i+".jpg"));
//			file = new File("C:\\RImage\\img"+i+".txt");
//			fileWrite = new FileWriter(file, true);
//			fileWrite.write(textList.get(i));
//			fileWrite.flush();
//		}
//		fileWrite.close();

		intent.putExtra("Bitmap",imageList);
		intent.putExtra("Bname",textList);
		Log.i("sock : ","before startActivity");
		context.startActivity(intent);

	}
}
