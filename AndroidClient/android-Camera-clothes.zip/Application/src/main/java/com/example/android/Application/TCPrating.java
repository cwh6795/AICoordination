package com.example.android.Application;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class TCPrating extends Thread {
    public static final int ServerPort = 8080;
    public static final String ServerIP = "www.wony-nas.kro.kr";
    OutputStream os;
    OutputStreamWriter osw = null;
    private static Socket sock;
    String result;
    Context context;


    public TCPrating(int good, int bad)
    {
        result = good + "_" + bad;
    }

    @Override
    public void run() {
        super.run();
        Log.i("sock : ","second sock about to start");
        try {
            sock = new Socket(ServerIP,ServerPort);
            os = sock.getOutputStream();
            osw = new OutputStreamWriter(os);
            osw.write(result);
            osw.close();
            os.close();
            sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        restartApp(context);

    }
    public void setContext(Context c)
    {
        context = c;
    }
    public static void restartApp(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = packageManager.getLaunchIntentForPackage(context.getPackageName());
        ComponentName componentName = intent.getComponent();
        Intent mainIntent = Intent.makeRestartActivityTask(componentName);
        context.startActivity(mainIntent);
        System.exit(0);
    }
}
