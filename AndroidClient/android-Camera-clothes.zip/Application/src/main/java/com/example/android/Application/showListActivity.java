package com.example.android.Application;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.android.camera2basic.R;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

public class showListActivity extends AppCompatActivity {
    ArrayList<byte[]> imageList = null;
    ArrayList<String> name = null;

    Button btn_home;

    int int_good = 0;
    int int_bad = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);

        Log.i("sock : ","startActivity's started");
        Intent intent = getIntent();
        imageList = (ArrayList<byte[]>) intent.getExtras().get("Bitmap");
        Log.i("sock : ","get Array Bitmap");
        name = intent.getStringArrayListExtra("Bname");
        Log.i("sock : ","get Array name");

        LinearLayout list_item = findViewById(R.id.inner);
        LayoutInflater inflater = LayoutInflater.from(this);

        ArrayList <String>arrayList = new ArrayList<>();
        arrayList.add("nothing");

        for(int i = 0; i< name.size() ; i++)
        {
            View view = inflater.inflate(R.layout.view_item, list_item, false);

            TextView textView = view.findViewById(R.id.textView);
            textView.setText(name.get(i));

            ImageView imageView = view.findViewById(R.id.imageView);
            imageView.setImageBitmap(BitmapFactory.decodeStream(new ByteArrayInputStream(imageList.get(i))));

            list_item.addView(view);

            arrayList.add(Integer.toString(i+1));

        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                arrayList);

        Spinner spinner_good = (Spinner)findViewById(R.id.good);
        spinner_good.setAdapter(arrayAdapter);
        spinner_good.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int_good = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                int_good = 0;
            }
        });
        Log.i("sock : ","spinner good set");

        Spinner spinner_bad = (Spinner)findViewById(R.id.bad);
        spinner_bad.setAdapter(arrayAdapter);
        spinner_bad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int_bad = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                int_bad = 0;
            }
        });
        Log.i("sock : ","spinner bad set");



        btn_home = findViewById(R.id.btn_home);
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TCPrating tcprating = new TCPrating(int_good,int_bad);
                tcprating.start();
                Intent intent_home = new Intent(showListActivity.this,start.class);
                startActivity(intent_home);
            }
        });


    }
}
