package com.example.android.Application;

import java.io.Serializable;

public class transform implements Serializable {
    private static final long serialVersionUID = 1L;
    byte [] b;
    String s;
    public transform(byte[] b, String s)
    {
        this.b = b;
        this.s = s;
    }

}
