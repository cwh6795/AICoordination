package com.example.android.Application;


import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;


public class TCPClient extends Thread {
    byte[] bytes;
    String name;
    Context context;

    public TCPClient(byte[] bytes , Context c, String name){
       this.bytes = bytes;
       context = c;
       this.name = name;
    }


    public static final int ServerPort = 8080;
    public static final String ServerIP = "www.wony-nas.kro.kr";
    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;
    OutputStream os;
    private static Socket sock;

    @Override
    public void run() {
        Log.i("sock : ","sock about to start");

        try {

            transform t = new transform(bytes, name);
            Object object = (Object)t;

            sock = new Socket(ServerIP,ServerPort);
            os = sock.getOutputStream();
            objectOutputStream = new ObjectOutputStream(os);
            objectOutputStream.writeObject(object);
            objectOutputStream.flush();


            objectInputStream = new ObjectInputStream(sock.getInputStream());
            imgList imgList = (imgList)objectInputStream.readObject();
            Log.i("sock : ","received data from Server");
            imgList.setContext(context);
            imgList.showimg();
            objectOutputStream.close();
            os.close();
            sock.close();
        } catch (IOException e) {
            Log.i("sock :  ","sock error ");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
//        Log.i("sock : ","sock is "+sock);
//            networkWriter = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
//            networkReader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
//            dataOutput = new DataOutputStream(sock.getOutputStream());


        //byteArrayInputStream = new ByteArrayInputStream(bytes);

    }




}
