package com.example.android.Application;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.android.camera2basic.R;

public class show_prev extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_prev);

        ScrollView scrollView = findViewById(R.id.scrollView);

        LayoutInflater inflater = (LayoutInflater)this.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
        View view1 = inflater.inflate(R.layout.scroll_item, scrollView, false);
        TextView textView = view1.findViewById(R.id.textView);


        ImageView imageView = view1.findViewById(R.id.imageView);

    }
}
