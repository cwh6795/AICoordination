package com.example.android.Application;

import android.graphics.Bitmap;

import java.util.ArrayList;

public class prev_container {
    Bitmap first;
    ArrayList<String> name;
    ArrayList<byte[]> img;

    public prev_container(Bitmap first, ArrayList<String> name,  ArrayList<byte[]> img)
    {
        this.first = first;
        this.name = name;
        this.img = img;
    }
}
