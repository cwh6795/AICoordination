package com.example.android.Application;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.android.camera2basic.R;

import java.io.ByteArrayInputStream;

public class popup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);
        Intent intent = getIntent();
        byte[] image = intent.getByteArrayExtra("pop_byte");
        ImageView imageView = findViewById(R.id.extended_imageview);
        imageView.setImageBitmap(BitmapFactory.decodeStream(new ByteArrayInputStream(image)));

        Button button = findViewById(R.id.btn_pop_close);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
