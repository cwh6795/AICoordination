package com.example.android.Application;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;


public class imgList implements Serializable
{
	private static final long serialVersionUID = 1L;
	ArrayList<byte[]> imageList;
	ArrayList<String> textList;
	Context context;
	Intent intent;
	String cloth_type;

	Bitmap Bimg;
	public imgList(ArrayList<byte[]> i, ArrayList<String> t)
	{
		imageList = i;
		textList = t;

	}
	void setContext(Context c)
	{
		context = c;
//		intent = new Intent(context, showListActivity.class);
		if(cloth_type.equals("bot"))
		{
			intent = new Intent(context, showListActivity.class);
		}
		else
		{
			intent = new Intent(context, showListActivity_bottom.class);
		}
	}
	void setimgByte(byte[] b)
	{
		Bimg = resizeBitmapImage(BitmapFactory.decodeByteArray(b,0,b.length), 300);
		//Bimg = imgRotate(Bimg, 90);

		Bimg = rotateImage(Bimg, 90);
	}
	void showimg()
	{
		Log.i("sock : ","showimg started");

		intent.putExtra("Bitmap",imageList);
		intent.putExtra("Bname",textList);
		intent.putExtra("Bimg",Bimg);
		intent.putExtra("cloth_type", cloth_type);
		Log.i("sock : ","before startActivity");
		context.startActivity(intent);

	}
	public Bitmap resizeBitmapImage(Bitmap source, int maxResolution)
	{
		int width = source.getWidth();
		int height = source.getHeight();
		int newWidth = width;
		int newHeight = height;
		float rate = 0.0f;

		if(width > height)
		{
			if(maxResolution < width)
			{
				rate = maxResolution / (float) width;
				newHeight = (int) (height * rate);
				newWidth = maxResolution;
			}
		}
		else
		{
			if(maxResolution < height)
			{
				rate = maxResolution / (float) height;
				newWidth = (int) (width * rate);
				newHeight = maxResolution;
			}
		}

		return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
	}
	private Bitmap imgRotate(Bitmap bitmap, int angle){
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();

		Matrix matrix = new Matrix();
		matrix.postRotate(angle);

		Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
		bitmap.recycle();

		return resizedBitmap;
	}
	public Bitmap rotateImage(Bitmap src, float degree) {


		Matrix matrix = new Matrix();

		matrix.postRotate(degree);

		return Bitmap.createBitmap(src, 0, 0, src.getWidth(),
				src.getHeight(), matrix, true);

	}





}
