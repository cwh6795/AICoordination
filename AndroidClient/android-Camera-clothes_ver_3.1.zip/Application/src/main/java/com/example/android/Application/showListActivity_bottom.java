package com.example.android.Application;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.android.camera2basic.R;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;

public class showListActivity_bottom extends AppCompatActivity {
    ArrayList<byte[]> imageList = null;
    ArrayList<String> name = null;
    ArrayList<String>arrayList;
    ArrayList<ArrayList> big;
    ArrayList<byte[]> array_bytes;

    Button btn_home;
    byte[] imgByte;
    Bitmap Bimg;
    Context context;

    int int_good = 0;
    int int_bad = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list_bottom);

        Log.i("sock : ","startActivity's started");
        Intent intent = getIntent();

        context = getApplicationContext();


        imageList = (ArrayList<byte[]>) intent.getExtras().get("Bitmap");
        Log.i("sock : ","get Array Bitmap");
        name = intent.getStringArrayListExtra("Bname");
        Log.i("sock : ","get Array name");


        Bimg = (Bitmap) intent.getExtras().get("Bimg");
        ImageView bitmapView = findViewById(R.id.selfBitmap_bottom);
        Log.i("sock : ","findView - selfBitmap done");
        bitmapView.setImageBitmap(Bimg);

        arrayList = new ArrayList<>();
        arrayList.add("nothing");

        for(int i=0; i<imageList.size();i++)
        {
            arrayList.add(""+(i+1));
        }

        Adapter adapter = new Adapter(this.getApplicationContext());
        ViewPager viewPager = findViewById(R.id.inner_bottom);
        viewPager.setAdapter(adapter);


        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                arrayList);

        Spinner spinner_good = (Spinner)findViewById(R.id.good_bottom);
        spinner_good.setAdapter(arrayAdapter);
        spinner_good.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int_good = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                int_good = 0;
            }
        });
        Log.i("sock : ","spinner good set");

        Spinner spinner_bad = (Spinner)findViewById(R.id.bad_bottom);
        spinner_bad.setAdapter(arrayAdapter);
        spinner_bad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int_bad = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                int_bad = 0;
            }
        });
        Log.i("sock : ","spinner bad set");



        btn_home = findViewById(R.id.btn_home_bottom);
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TCPrating tcprating = new TCPrating(int_good,int_bad);
                tcprating.setContext(context);
                tcprating.start();
//                finishAffinity();           // 루트 액티비티까지 모두 종료
//                System.runFinalization();   // 쓰레드 종료까지 기다림
//                System.exit(0);
//                Intent intent_home = new Intent(showListActivity.this,start.class);
//                startActivity(intent_home);

            }
        });



    }





    class Adapter extends PagerAdapter
    {
        Context context;
        public Adapter(Context c)
        {
            context = c;
        }

        @Override
        public int getCount() {
            return name.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == ((View)o);

        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            // LinearLayout list_item = findViewById(R.id.inner);
            SharedPreferences sp = getSharedPreferences("ArrayPref",MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            // 이 부분 아직 사용하지 않음


            LayoutInflater inflater = (LayoutInflater)context.getSystemService
                    (Context.LAYOUT_INFLATER_SERVICE);

            View view = inflater.inflate(R.layout.view_item, container, false);
            TextView textView = view.findViewById(R.id.textView);
            textView.setText(name.get(position));

            ImageView imageView = view.findViewById(R.id.imageView);
            imageView.setImageBitmap(BitmapFactory.decodeStream(new ByteArrayInputStream(imageList.get(position))));
            final byte[] pop_image = imageList.get(position);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, popup.class);
                    intent.putExtra("pop_byte",pop_image);
                    startActivity(intent);
                }
            });
            container.addView(view);
//            arrayList.add(Integer.toString(position+1));

//            big.add(name); big.add(imageList);
//            editor.putString("category1", big.toString());
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.invalidate();
        }
    }



}


