package com.example.android.Application;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.example.android.camera2basic.R;

public class start extends AppCompatActivity {
    Button btnStart;
    Intent intent;
    String spinner_Value, final_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        final RadioGroup group = findViewById(R.id.radio_group);
        Spinner spinner = (Spinner)findViewById(R.id.spinner_style);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner_Value = parent.getItemAtPosition(position).toString();
                Log.i("sock : ","spinner value -> "+spinner_Value);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });

        btnStart = (Button)findViewById(R.id.btn_start);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("sock : ","set on Click Started ");
                int id = group.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton)findViewById(id);
                EditText ageText = findViewById(R.id.age);
                Log.i("sock : ","EditText-> "+ageText.getText().toString());
                Log.i("sock : ","radioButton-> "+radioButton.getText().toString());
                final_name = radioButton.getText().toString()+"_"+ageText.getText().toString()+"_"+spinner_Value;
                Log.i("sock : ","final_name ->"+final_name);
                intent = new Intent(start.this, CameraActivity.class);
                intent.putExtra("img_name",final_name);
                startActivity(intent);
            }
        });


        //이전 기록 파트, 아직 구현이 힘들다.
//        Button prev = findViewById(R.id.btn_prev);
//        prev.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent2 = new Intent(start.this,show_prev.class);
//                startActivity(intent2);
//            }
//        });
    }
//    public void onClick(View target)
//    {
//        getSupportFragmentManager().beginTransaction()
//                .replace(R.id.container, Camera2BasicFragment.newInstance())
//                .commit();
//    }
}
